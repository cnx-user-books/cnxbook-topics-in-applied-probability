% file mcalc01   Data for software survey
minvec3;
DV = [A|Ac; A; B; C; A&B&C; Ac&Bc; (A&B)|(A&C)|(B&C); (A&Bc&C)  - 2*(Ac&B&C)];
DP = [1 0.8 0.65 0.3 0.1 0.05 0.65 0];
TV = [(A&B&Cc)|(A&Bc&C)|(Ac&B&C); Ac&Bc&C];
disp('Call for mincalc')